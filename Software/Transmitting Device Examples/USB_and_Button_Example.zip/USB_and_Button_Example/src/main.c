 /*
 * This Program is for a transmitting NRF52 device. It will work over USB with the given Python control app
 * or alternatively simply send a VTS trigger over ESB when the voltage goes high on pin D2
 * 
 * The Program Uses Building Blocks from Zephyr Provided Samples, and Hence the License is Referenced:
 *
 * Copyright (c) 2018 Nordic Semiconductor ASA
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

 #include <zephyr/drivers/clock_control.h>
 #include <zephyr/drivers/clock_control/nrf_clock_control.h>
 #if defined(NRF54L15_XXAA)
 #include <hal/nrf_clock.h>
 #endif /* defined(NRF54L15_XXAA) */
 #include <zephyr/drivers/gpio.h>
 #include <zephyr/irq.h>
 #include <zephyr/logging/log.h>
 #include <nrf.h>
 #include <esb.h>
 #include <zephyr/device.h>
 #include <zephyr/devicetree.h>
 #include <zephyr/kernel.h>
 #include <zephyr/types.h>
 #include <dk_buttons_and_leds.h>
 #if defined(CONFIG_CLOCK_CONTROL_NRF2)
 #include <hal/nrf_lrcconf.h>
 #endif
 
 #include <sample_usbd.h>
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <zephyr/drivers/uart.h>
 #include <zephyr/sys/ring_buffer.h>
 
 #include <zephyr/usb/usb_device.h>
 #include <zephyr/usb/usbd.h>
 
 LOG_MODULE_REGISTER(esb_usb_app, LOG_LEVEL_INF);
 
 /* USB CDC ACM device */
 const struct device *const uart_dev = DEVICE_DT_GET_ONE(zephyr_cdc_acm_uart);
 
 /* ESB state and payload definitions */
 static bool ready = true;
 static struct esb_payload rx_payload;
 static struct esb_payload tx_payload = ESB_CREATE_PAYLOAD(0, 0x00, 0xFF, 0xFF);
 static struct esb_payload usb_tx_payload = ESB_CREATE_PAYLOAD(0, 0x01, 0x00, 0x00, 0x00, 0X00, 0X00, 0X00, 0X00);
 
 /* Button configuration */
 #define BUTTON_PIN 28  // P0.28
 #define DEBOUNCE_MS 50
 
 /* Declare a GPIO callback structure for button interrupt */
 static struct gpio_callback button_cb_data;
 
 /* Define GPIO device */
 static const struct device *gpio_dev;
 
 /* Debounce timer */
 static struct k_timer debounce_timer;
 static volatile bool button_pressed_recently = false;
 
 /* USB data handling */
 #define RING_BUF_SIZE 1024
 uint8_t ring_buffer[RING_BUF_SIZE];
 
 /* Buffer for storing incoming data until a full line is received */
 #define LINE_BUF_SIZE 128
 static char line_buf[LINE_BUF_SIZE];
 static size_t line_buf_pos = 0;
 
 struct ring_buf ringbuf;
 
 static bool rx_throttled;
 
 /* Parsed values from USB CDC */
 static int mode_value;
 static int second_value;
 static int third_value;
 static int fourth_value;
 
 #define _RADIO_SHORTS_COMMON                                                   \
     (RADIO_SHORTS_READY_START_Msk | RADIO_SHORTS_END_DISABLE_Msk |         \
      RADIO_SHORTS_ADDRESS_RSSISTART_Msk |                                  \
      RADIO_SHORTS_DISABLED_RSSISTOP_Msk)
 
 /* Debounce timer callback function */
 static void debounce_timeout(struct k_timer *timer)
 {
     button_pressed_recently = false;
 }
 
 /* ESB event handler */
 void event_handler(struct esb_evt const *event)
 {
     ready = true;
 
     switch (event->evt_id) {
     case ESB_EVENT_TX_SUCCESS:
         LOG_DBG("TX SUCCESS EVENT");
         break;
     case ESB_EVENT_TX_FAILED:
         LOG_DBG("TX FAILED EVENT");
         break;
     case ESB_EVENT_RX_RECEIVED:
         while (esb_read_rx_payload(&rx_payload) == 0) {
             LOG_DBG("Packet received, len %d : "
                 "0x%02x, 0x%02x, 0x%02x, 0x%02x, "
                 "0x%02x, 0x%02x, 0x%02x, 0x%02x",
                 rx_payload.length, rx_payload.data[0],
                 rx_payload.data[1], rx_payload.data[2],
                 rx_payload.data[3], rx_payload.data[4],
                 rx_payload.data[5], rx_payload.data[6],
                 rx_payload.data[7]);
         }
         break;
     }
 }
 
 /* Function to transmit ESB payload */
 static int transmit_esb_payload(struct esb_payload *payload)
 {
     int err;
     
     if (!ready) {
         LOG_WRN("ESB not ready for transmission");
         return -EBUSY;
     }
     
     ready = false;
     esb_flush_tx();
     
     err = esb_write_payload(payload);
     if (err) {
         LOG_ERR("Payload write failed, err %d", err);
         ready = true;
         return err;
     }
     
     LOG_DBG("ESB payload sent successfully");
     return 0;
 }
 
 /* Button press interrupt handler with high priority */
 static void button_pressed_handler(const struct device *dev,
                                   struct gpio_callback *cb,
                                   uint32_t pins)
 {
     /* Check if this is a new button press (not during debounce period) */
     if (!button_pressed_recently) {
         /* Set debounce flag immediately - before transmission */
         button_pressed_recently = true;
         
         /* Start debounce timer to prevent repeat transmissions */
         k_timer_start(&debounce_timer, K_MSEC(DEBOUNCE_MS), K_NO_WAIT);
         
         /* Send the pre-defined payload */
         transmit_esb_payload(&tx_payload);
         
         LOG_DBG("Button pressed - sending payload");
     }
 }
 
 /* Function to parse hex values from a string*/
 static int parse_hex_data(const char *line)
 {
     /* Static buffers for storing copies of the string parts */
     static char str_copy[LINE_BUF_SIZE];
     char *token;
     char *next_ptr;
     
     /* Copy the incoming string to our buffer */
     if (strlen(line) >= LINE_BUF_SIZE) {
         LOG_ERR("Input line too long");
         return -EINVAL;
     }
     strcpy(str_copy, line);
     
     /* First value: Mode Value (wave or sleep change) */
     token = strtok_r(str_copy, ",", &next_ptr);
     if (token == NULL) {
         LOG_ERR("Failed to parse mode value");
         return -EINVAL;
     }
     
     mode_value = strtol(token, NULL, 16);
 
     /* Second value: voltage */
     token = strtok_r(NULL, ",", &next_ptr);
     if (token == NULL) {
         LOG_ERR("Failed to parse second value");
         return -EINVAL;
     }
     
     second_value = strtol(token, NULL, 16);
     
     /* Third value: frequency*/
     token = strtok_r(NULL, ",", &next_ptr);
     if (token == NULL) {
         LOG_ERR("Failed to parse third value");
         return -EINVAL;
     }
     
     third_value = strtol(token, NULL, 16);
     
     /* Fourth value: number of cycles */
     token = strtok_r(NULL, "\n", &next_ptr);
     if (token == NULL) {
         LOG_ERR("Failed to parse fourth value");
         return -EINVAL;
     }
     
     fourth_value = strtol(token, NULL, 16);    
     return 0;
 }
 
 /* Function to process a complete line of received data */
 static void process_line(const char *line)
 {
     /* Parse the hex data */
     if (parse_hex_data(line) == 0) {
         /* Format a response message */
         char response[64];
         snprintf(response, sizeof(response), 
                 "ACK: M=0x%x, V=0x%x, F=0x%x, C=0x%x\n", 
                 mode_value, second_value, third_value, fourth_value);
         
         /* Send response back through UART */
         for (size_t i = 0; i < strlen(response); i++) {
             ring_buf_put(&ringbuf, (uint8_t *)&response[i], 1);
         }
         
         uart_irq_tx_enable(uart_dev);
         
         /* Package the parsed values into an ESB payload and send it */
         usb_tx_payload.data[0] = mode_value;
 
         /* If mode_vale is 1 do a wave change request*/
         if (mode_value == 0x01){
             usb_tx_payload.data[1] = (second_value >> 8) & 0xFF;   /* Voltage High byte */
             usb_tx_payload.data[2] = second_value & 0xFF;          /* Voltage Low byte */
             usb_tx_payload.data[3] = fourth_value;                  /* Cycles byte */
             usb_tx_payload.data[4] = third_value;               /* Frequency byte */
         } else{
             /* otherwise it's a sleep request*/
             usb_tx_payload.data[1] = second_value;               /* Sleep Enable byte */
             usb_tx_payload.data[2] = fourth_value;                 /* On-Time byte */
             usb_tx_payload.data[3] = third_value;               /* Off-Time byte */
         }
 
         usb_tx_payload.length = 5;
 
 
         
         /* Send the payload */
         transmit_esb_payload(&usb_tx_payload);
         
         LOG_INF("USB data forwarded to ESB: V=0x%x, F=0x%x, C=0x%x", 
                 second_value, third_value, fourth_value);
     }
 }
 
 static inline void print_baudrate(const struct device *dev)
 {
     uint32_t baudrate;
     int ret;
 
     ret = uart_line_ctrl_get(dev, UART_LINE_CTRL_BAUD_RATE, &baudrate);
     if (ret) {
         LOG_WRN("Failed to get baudrate, ret code %d", ret);
     } else {
         LOG_INF("Baudrate %u", baudrate);
     }
 }
 
 #if defined(CONFIG_USB_DEVICE_STACK_NEXT)
 static struct usbd_context *sample_usbd;
 K_SEM_DEFINE(dtr_sem, 0, 1);
 
 static void sample_msg_cb(struct usbd_context *const ctx, const struct usbd_msg *msg)
 {
     LOG_INF("USBD message: %s", usbd_msg_type_string(msg->type));
 
     if (usbd_can_detect_vbus(ctx)) {
         if (msg->type == USBD_MSG_VBUS_READY) {
             if (usbd_enable(ctx)) {
                 LOG_ERR("Failed to enable device support");
             }
         }
 
         if (msg->type == USBD_MSG_VBUS_REMOVED) {
             if (usbd_disable(ctx)) {
                 LOG_ERR("Failed to disable device support");
             }
         }
     }
 
     if (msg->type == USBD_MSG_CDC_ACM_CONTROL_LINE_STATE) {
         uint32_t dtr = 0U;
 
         uart_line_ctrl_get(msg->dev, UART_LINE_CTRL_DTR, &dtr);
         if (dtr) {
             k_sem_give(&dtr_sem);
         }
     }
 
     if (msg->type == USBD_MSG_CDC_ACM_LINE_CODING) {
         print_baudrate(msg->dev);
     }
 }
 
 static int enable_usb_device_next(void)
 {
     int err;
 
     sample_usbd = sample_usbd_init_device(sample_msg_cb);
     if (sample_usbd == NULL) {
         LOG_ERR("Failed to initialize USB device");
         return -ENODEV;
     }
 
     if (!usbd_can_detect_vbus(sample_usbd)) {
         err = usbd_enable(sample_usbd);
         if (err) {
             LOG_ERR("Failed to enable device support");
             return err;
         }
     }
 
     LOG_INF("USB device support enabled");
 
     return 0;
 }
 #endif /* defined(CONFIG_USB_DEVICE_STACK_NEXT) */
 
 static void uart_interrupt_handler(const struct device *dev, void *user_data)
 {
     ARG_UNUSED(user_data);
 
     while (uart_irq_update(dev) && uart_irq_is_pending(dev)) {
         if (!rx_throttled && uart_irq_rx_ready(dev)) {
             int recv_len, rb_len;
             uint8_t buffer[64];
             size_t len = MIN(ring_buf_space_get(&ringbuf),
                     sizeof(buffer));
 
             if (len == 0) {
                 /* Throttle because ring buffer is full */
                 uart_irq_rx_disable(dev);
                 rx_throttled = true;
                 continue;
             }
 
             recv_len = uart_fifo_read(dev, buffer, len);
             if (recv_len < 0) {
                 LOG_ERR("Failed to read UART FIFO");
                 recv_len = 0;
             };
 
             /* Process received data byte by byte to look for complete lines */
             for (int i = 0; i < recv_len; i++) {
                 /* Add to line buffer if there's space */
                 if (line_buf_pos < LINE_BUF_SIZE - 1) {
                     line_buf[line_buf_pos++] = buffer[i];
                     
                     /* Check for end of line (newline character) */
                     if (buffer[i] == '\n') {
                         /* Null-terminate the string */
                         line_buf[line_buf_pos] = '\0';
                         
                         /* Process the complete line */
                         process_line(line_buf);
                         
                         /* Reset buffer position for the next line */
                         line_buf_pos = 0;
                     }
                 } else {
                     /* Buffer overflow, reset buffer position */
                     LOG_ERR("Line buffer overflow, discarding data");
                     line_buf_pos = 0;
                 }
             }
 
             /* Echo date */
             rb_len = ring_buf_put(&ringbuf, buffer, recv_len);
             if (rb_len < recv_len) {
                 LOG_ERR("Drop %u bytes", recv_len - rb_len);
             }
 
             LOG_DBG("tty fifo -> ringbuf %d bytes", rb_len);
             if (rb_len) {
                 uart_irq_tx_enable(dev);
             }
         }
 
         if (uart_irq_tx_ready(dev)) {
             uint8_t buffer[64];
             int rb_len, send_len;
 
             rb_len = ring_buf_get(&ringbuf, buffer, sizeof(buffer));
             if (!rb_len) {
                 LOG_DBG("Ring buffer empty, disable TX IRQ");
                 uart_irq_tx_disable(dev);
                 continue;
             }
 
             if (rx_throttled) {
                 uart_irq_rx_enable(dev);
                 rx_throttled = false;
             }
 
             send_len = uart_fifo_fill(dev, buffer, rb_len);
             if (send_len < rb_len) {
                 LOG_ERR("Drop %d bytes", rb_len - send_len);
             }
 
             LOG_DBG("ringbuf -> tty fifo %d bytes", send_len);
         }
     }
 }
 
 #if defined(CONFIG_CLOCK_CONTROL_NRF)
 int clocks_start(void)
 {
     int err;
     int res;
     struct onoff_manager *clk_mgr;
     struct onoff_client clk_cli;
 
     clk_mgr = z_nrf_clock_control_get_onoff(CLOCK_CONTROL_NRF_SUBSYS_HF);
     if (!clk_mgr) {
         LOG_ERR("Unable to get the Clock manager");
         return -ENXIO;
     }
 
     sys_notify_init_spinwait(&clk_cli.notify);
 
     err = onoff_request(clk_mgr, &clk_cli);
     if (err < 0) {
         LOG_ERR("Clock request failed: %d", err);
         return err;
     }
 
     do {
         err = sys_notify_fetch_result(&clk_cli.notify, &res);
         if (!err && res) {
             LOG_ERR("Clock could not be started: %d", res);
             return res;
         }
     } while (err);
 
 #if defined(NRF54L15_XXAA)
     /* MLTPAN-20 */
     nrf_clock_task_trigger(NRF_CLOCK, NRF_CLOCK_TASK_PLLSTART);
 #endif /* defined(NRF54L15_XXAA) */
 
     LOG_DBG("HF clock started");
     return 0;
 }
 
 #elif defined(CONFIG_CLOCK_CONTROL_NRF2)
 
 int clocks_start(void)
 {
     int err;
     int res;
     const struct device *radio_clk_dev =
         DEVICE_DT_GET_OR_NULL(DT_CLOCKS_CTLR(DT_NODELABEL(radio)));
     struct onoff_client radio_cli;
 
     /** Keep radio domain powered all the time to reduce latency. */
     nrf_lrcconf_poweron_force_set(NRF_LRCCONF010, NRF_LRCCONF_POWER_DOMAIN_1, true);
 
     sys_notify_init_spinwait(&radio_cli.notify);
 
     err = nrf_clock_control_request(radio_clk_dev, NULL, &radio_cli);
 
     do {
         err = sys_notify_fetch_result(&radio_cli.notify, &res);
         if (!err && res) {
             LOG_ERR("Clock could not be started: %d", res);
             return res;
         }
     } while (err == -EAGAIN);
 
 #if defined(NRF54L15_XXAA)
     /* MLTPAN-20 */
     nrf_clock_task_trigger(NRF_CLOCK, NRF_CLOCK_TASK_PLLSTART);
 #endif /* defined(NRF54L15_XXAA) */
 
     LOG_DBG("HF clock started");
     return 0;
 }
 
 #else
 BUILD_ASSERT(false, "No Clock Control driver");
 #endif /* defined(CONFIG_CLOCK_CONTROL_NRF2) */
 
 int esb_initialize(void)
 {
     int err;
     /* These are arbitrary default addresses. In end user products
      * different addresses should be used for each set of devices.
      */
     uint8_t base_addr_0[4] = {0xE7, 0xE7, 0xE7, 0xE7};
     uint8_t base_addr_1[4] = {0xC2, 0xC2, 0xC2, 0xC2};
     uint8_t addr_prefix[8] = {0xE7, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8};
 
     struct esb_config config = ESB_DEFAULT_CONFIG;
 
     config.protocol = ESB_PROTOCOL_ESB_DPL;
     config.retransmit_delay = 400;
     config.bitrate = ESB_BITRATE_2MBPS;
     config.tx_output_power = ESB_TX_POWER_4DBM;
     config.event_handler = event_handler;
     config.mode = ESB_MODE_PTX;
     config.selective_auto_ack = true;
     config.use_fast_ramp_up = true;
     
 
     err = esb_init(&config);
 
     if (err) {
         return err;
     }
 
     err = esb_set_base_address_0(base_addr_0);
     if (err) {
         return err;
     }
 
     err = esb_set_base_address_1(base_addr_1);
     if (err) {
         return err;
     }
 
     err = esb_set_prefixes(addr_prefix, ARRAY_SIZE(addr_prefix));
     if (err) {
         return err;
     }
 
     return 0;
 }
 
 /* Initialize button */
 int button_init(void)
 {
     int err;
     
     /* Get GPIO device */
     gpio_dev = DEVICE_DT_GET(DT_NODELABEL(gpio0));
     if (!device_is_ready(gpio_dev)) {
         LOG_ERR("Error: GPIO device not ready");
         return -ENODEV;
     }
     
     /* Configure button pin with pull-down and activate on high */
     err = gpio_pin_configure(gpio_dev, BUTTON_PIN, 
                            GPIO_INPUT | GPIO_PULL_DOWN | GPIO_ACTIVE_HIGH);
     if (err) {
         LOG_ERR("Error %d: Failed to configure button pin", err);
         return err;
     }
     
     /* Initialize debounce timer */
     k_timer_init(&debounce_timer, debounce_timeout, NULL);
     
     /* Initialize button callback with high priority */
     gpio_init_callback(&button_cb_data, button_pressed_handler, BIT(BUTTON_PIN));
     
     /* Add callback */
     err = gpio_add_callback(gpio_dev, &button_cb_data);
     if (err) {
         LOG_ERR("Error %d: Failed to add button callback", err);
         return err;
     }
     
     #ifdef CONFIG_GPIO_NRFX
     NRF_GPIOTE->INTENSET = GPIOTE_INTENSET_PORT_Msk;
     NVIC_SetPriority(GPIOTE_IRQn, 0); /* Set to highest priority (0) */
     #endif
     
     /* Enable button interrupt on rising edge (button press) */
     err = gpio_pin_interrupt_configure(gpio_dev, BUTTON_PIN, GPIO_INT_EDGE_TO_ACTIVE);
     if (err) {
         LOG_ERR("Error %d: Failed to configure button interrupt", err);
         return err;
     }
     
     LOG_INF("Button successfully initialized on pin P0.%d", BUTTON_PIN);
     return 0;
 }
 
 int main(void)
 {
     int err;
 
     LOG_INF("ESB + USB CDC ACM merged sample");
 
     /* Initialize ESB radio */
     err = clocks_start();
     if (err) {
         LOG_ERR("Clock initialization failed, err %d", err);
         return 0;
     }
 
 
     err = esb_initialize();
     if (err) {
         LOG_ERR("ESB initialization failed, err %d", err);
         return 0;
     }
     
     /* Initialize button with interrupt */
     err = button_init();
     if (err) {
         LOG_ERR("Button initialization failed, err %d", err);
         return 0;
     }
 
     /* Initialize USB CDC ACM */
     if (!device_is_ready(uart_dev)) {
         LOG_ERR("CDC ACM device not ready");
         return 0;
     }
 
 #if defined(CONFIG_USB_DEVICE_STACK_NEXT)
     err = enable_usb_device_next();
 #else
     err = usb_enable(NULL);
 #endif
 
     if (err != 0) {
         LOG_ERR("Failed to enable USB, err %d", err);
         return 0;
     }
 
     ring_buf_init(&ringbuf, sizeof(ring_buffer), ring_buffer);
 
     LOG_INF("Waiting for DTR on USB CDC ACM");
 
 #if defined(CONFIG_USB_DEVICE_STACK_NEXT)
     k_sem_take(&dtr_sem, K_FOREVER);
 #else
     while (true) {
         uint32_t dtr = 0U;
 
         uart_line_ctrl_get(uart_dev, UART_LINE_CTRL_DTR, &dtr);
         if (dtr) {
             break;
         } else {
             /* Give CPU resources to low priority threads. */
             k_sleep(K_MSEC(100));
         }
     }
 #endif
 
     LOG_INF("DTR set, USB CDC ACM connected");
 
     /* Optional control signals */
     err = uart_line_ctrl_set(uart_dev, UART_LINE_CTRL_DCD, 1);
     if (err) {
         LOG_WRN("Failed to set DCD, ret code %d", err);
     }
 
     err = uart_line_ctrl_set(uart_dev, UART_LINE_CTRL_DSR, 1);
     if (err) {
         LOG_WRN("Failed to set DSR, ret code %d", err);
     }
 
     /* Wait 100ms for the host to do all settings */
     k_msleep(100);
 
 #ifndef CONFIG_USB_DEVICE_STACK_NEXT
     print_baudrate(uart_dev);
 #endif
     
     /* Set up UART interrupt handler for USB data */
     uart_irq_callback_set(uart_dev, uart_interrupt_handler);
 
     /* Enable rx interrupts */
     uart_irq_rx_enable(uart_dev);
 
     /* Configure ESB default payload */
     tx_payload.noack = false;
     usb_tx_payload.noack = false;
     
     LOG_INF("Initialization complete");
     LOG_INF("Press button on P0.28 to send default packet");
     LOG_INF("Send data via USB CDC ACM in format '0xVVV,0xFFF,0xCCC' to transmit via ESB");
 
     while (1) {
         /* Main loop just sleeps - all action happens in interrupt context */
         k_sleep(K_SECONDS(1));
     }
 }