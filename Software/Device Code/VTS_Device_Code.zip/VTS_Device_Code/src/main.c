 /*
 * This Program is for the NRF52 SOC Embedded on the Actuator Device. It handles ESB packet reception,
 * VTS application, and Sleep Modes.
 * 
 * The Program Uses Building Blocks from Zephyr Provided Samples, and Hence the License is Referenced:
 *
 * Copyright (c) 2018 Nordic Semiconductor ASA
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */


 #include <zephyr/kernel.h>
 #include <zephyr/sys/reboot.h>
 #include <zephyr/device.h>
 #include <string.h>
 #include <zephyr/drivers/flash.h>
 #include <zephyr/storage/flash_map.h>
 #include <zephyr/fs/nvs.h>
 #include <zephyr/device.h>
 #include <zephyr/devicetree.h>
 #include <zephyr/drivers/clock_control.h>
 #include <zephyr/drivers/clock_control/nrf_clock_control.h>
 #if defined(NRF54L15_XXAA)
 #include <hal/nrf_clock.h>
 #endif
 #include <zephyr/drivers/gpio.h>
 #include <zephyr/irq.h>
 #include <zephyr/logging/log.h>
 #include <nrf.h>
 #include <esb.h>
 #include <stdio.h>
 #include <zephyr/types.h>
 #include <zephyr/drivers/i2c.h>
 #if defined(CONFIG_CLOCK_CONTROL_NRF2)
 #include <hal/nrf_lrcconf.h>
 #endif

LOG_MODULE_REGISTER(esb_prx, CONFIG_ESB_PRX_APP_LOG_LEVEL);

static struct nvs_fs fs;

#define NVS_PARTITION		storage_partition
#define NVS_PARTITION_DEVICE	FIXED_PARTITION_DEVICE(NVS_PARTITION)
#define NVS_PARTITION_OFFSET	FIXED_PARTITION_OFFSET(NVS_PARTITION)
#define KEY_ID 1


#define BOS_ADDRESS 0x44
#define CONFIG_ADDRESS 0x05
#define I2C1_NODE DT_NODELABEL(bos)

uint8_t AMP_MSB, AMP_LSB, CYC, FREQ, SLEEP_CONFIG, SLEEP_ON, SLEEP_OFF;
uint8_t key[7];

/* Sleep Tracker */
enum sleep_state {
	AWAKE,
	ASLEEP
};

static struct {
    enum sleep_state current_state;
    uint32_t last_state_change_time;
} sleep_config = {
    .current_state = AWAKE,
    .last_state_change_time = 0
};

static const struct i2c_dt_spec dev_i2c = I2C_DT_SPEC_GET(I2C1_NODE);

static struct esb_payload rx_payload;
static struct esb_payload tx_payload = ESB_CREATE_PAYLOAD(0,
	0x00, 0x00, 0x00);


void check_and_update_sleep_state(void);
void enter_sleep_mode(void);
void wake_up_device(void);

static void haptic_work_handler(struct k_work *work);
K_WORK_DEFINE(haptic_work, haptic_work_handler);

static void haptic_change_handler(struct k_work *work);
K_WORK_DEFINE(haptic_change, haptic_change_handler);

static void sleep_change_handler(struct k_work *work);
K_WORK_DEFINE(sleep_change, sleep_change_handler);

static struct k_sem haptic_sem;

static void haptic_work_handler(struct k_work *work)
{
    int err;
    uint8_t pulse_data[8] = {0x05, 0x16, 0x10, 0x00, 0x00, 0x12, 0x00, 0x00};

    if (!device_is_ready(dev_i2c.bus)) {
        LOG_ERR("I2C device not ready");
        k_sem_give(&haptic_sem);  // Release semaphore in case of failure
        return;
    }

    err = i2c_write_dt(&dev_i2c, pulse_data, sizeof(pulse_data));
    if (err < 0) {
        LOG_ERR("Write Failed: %d", err);
		k_sem_give(&haptic_sem); 
    }
	k_sem_give(&haptic_sem);  // Release the semaphore after haptic action is done
	LOG_DBG("Sent Pulse");

    }

// Instead of calling activate_haptic() directly, use:
void activate_haptic(void)
{
	if (k_sem_take(&haptic_sem, K_NO_WAIT) != 0) {
        LOG_DBG("BOS1921 already in use... skipping...");
        return;
    }

	k_work_submit(&haptic_work);
}

static void haptic_change_handler(struct k_work *work)
{
    LOG_DBG("Sending Pulse");
    int err;

	uint8_t new_wave_data[28] = {0x05, 0x16, 0x10, 0x00, 0x00, 0x01, 0x00, 
		0x00, 0x01 , 0x00, 0x01, 0x02, 0x00, 0x01, 0x00, 0x01, 0x01,
		0x00, rx_payload.data[1], rx_payload.data[2], rx_payload.data[3], rx_payload.data[4],
		0x04, 0x00, 0x00, 0x12, 0x00, 0x00};

	LOG_INF("Setting up Waveform Slice: ");
	for (int i = 0; i < sizeof(new_wave_data); i++) {
		LOG_INF("0x%02X", new_wave_data[i]);
	}
	if (!device_is_ready(dev_i2c.bus)){
		printk("i2c dev not ready\n");
		k_sem_give(&haptic_sem);
		return;
	}
	
	/*Save the new wave characteristics so they're now default on power-up*/
	key[0] = rx_payload.data[1];	
	key[1] = rx_payload.data[2];
	key[2] = rx_payload.data[3];		
	key[3] = rx_payload.data[4];		
	
	(void)nvs_write(&fs, KEY_ID, &key, sizeof(key));

	err = i2c_write_dt(&dev_i2c, new_wave_data, sizeof(new_wave_data));
	if (err<0){
		printk("Wave Change Write Failed: %d\n", err);
		k_sem_give(&haptic_sem);
		return;
	}
    k_sem_give(&haptic_sem);  // Release the semaphore after haptic action is done
}


void change_haptic(void)
{
	if (k_sem_take(&haptic_sem, K_NO_WAIT) != 0) {
        LOG_DBG("BOS1921 already in use... skipping...");
        return;
    }

	k_work_submit(&haptic_change);
}

static void sleep_change_handler(struct k_work *work)
{
	SLEEP_CONFIG = rx_payload.data[1];
	SLEEP_ON = rx_payload.data[2];
	SLEEP_OFF = rx_payload.data[3];

	key[4] = SLEEP_CONFIG;
	key[5] = SLEEP_ON;
	key[6] = SLEEP_OFF;


	(void)nvs_write(&fs, KEY_ID, &key, sizeof(key));
}

void change_sleep(void)
{
	k_work_submit(&sleep_change);
}


void check_and_update_sleep_state(void){
	if (SLEEP_CONFIG == 0X00){
		sleep_config.current_state = AWAKE;
		return;
	}

	uint32_t current_time = k_uptime_get_32();
	uint32_t elapsed_time = current_time - sleep_config.last_state_change_time;

	/* Get number of times that full-cycle has happened in case ESB is infrequent */
	int cycles  = floor((elapsed_time)/((SLEEP_ON+SLEEP_OFF)*10000));

	elapsed_time -= cycles*(SLEEP_ON+SLEEP_OFF);

	switch (sleep_config.current_state){
		case AWAKE:
			/* Multiplying by 300,000 as SLEEP_ON = 0x01 should represent 5 minutes (300,000 ms) */
			if (elapsed_time >= SLEEP_ON * 300000){
				LOG_INF("Entering Sleep - Device Will Only Repond to Sleep Change Requests...");
				sleep_config.current_state = ASLEEP;
				sleep_config.last_state_change_time = k_uptime_get_32();
			}
			break;
		case ASLEEP:
			if (elapsed_time >= SLEEP_OFF * 10000){
				LOG_INF("Waking...");
				sleep_config.current_state = AWAKE;
				sleep_config.last_state_change_time = k_uptime_get_32();
			}
			break;
	}

}

void event_handler(struct esb_evt const *event)
{
	switch (event->evt_id) {
	case ESB_EVENT_TX_SUCCESS:
		LOG_DBG("TX SUCCESS EVENT");
		break;
	case ESB_EVENT_TX_FAILED:
		LOG_DBG("TX FAILED EVENT");
		break;
	case ESB_EVENT_RX_RECEIVED:
		if (esb_read_rx_payload(&rx_payload) == 0) {
			LOG_DBG("Packet received, len %d : "
				"0x%02x, 0x%02x, 0x%02x, 0x%02x, "
				"0x%02x, 0x%02x, 0x%02x, 0x%02x",
				rx_payload.length, rx_payload.data[0],
				rx_payload.data[1], rx_payload.data[2],
				rx_payload.data[3], rx_payload.data[4],
				rx_payload.data[5], rx_payload.data[6], rx_payload.data[7]);
		
			/* Only do any VTS changes/triggers if the device is awake*/
			if (sleep_config.current_state == AWAKE){
				if (rx_payload.data[0] == 0x00){
					activate_haptic();
				} else{
					if (rx_payload.data[0] == 0x01){
						LOG_DBG("VTS CHANGE REQUEST");
						change_haptic();
					}
				}
			}
			
			/*Always allow sleep change requests, so you don't have to catch it when awake*/
			if (rx_payload.data[0] == 0x02){
				LOG_DBG("SLEEP CHANGE REQUEST");
				change_sleep();
			}

			/* After handling any ESB packets, check if the device should be asleep*/
			check_and_update_sleep_state();

		} else {
			LOG_ERR("Error while reading rx packet");
		}
		break;
	}
}

#if defined(CONFIG_CLOCK_CONTROL_NRF)
int clocks_start(void)
{
	int err;
	int res;
	struct onoff_manager *clk_mgr;
	struct onoff_client clk_cli;

	clk_mgr = z_nrf_clock_control_get_onoff(CLOCK_CONTROL_NRF_SUBSYS_HF);
	if (!clk_mgr) {
		LOG_ERR("Unable to get the Clock manager");
		return -ENXIO;
	}

	sys_notify_init_spinwait(&clk_cli.notify);

	err = onoff_request(clk_mgr, &clk_cli);
	if (err < 0) {
		LOG_ERR("Clock request failed: %d", err);
		return err;
	}

	do {
		err = sys_notify_fetch_result(&clk_cli.notify, &res);
		if (!err && res) {
			LOG_ERR("Clock could not be started: %d", res);
			return res;
		}
	} while (err);

#if defined(NRF54L15_XXAA)
	/* MLTPAN-20 */
	nrf_clock_task_trigger(NRF_CLOCK, NRF_CLOCK_TASK_PLLSTART);
#endif /* defined(NRF54L15_XXAA) */

	LOG_DBG("HF clock started");
	return 0;
}

#elif defined(CONFIG_CLOCK_CONTROL_NRF2)

int clocks_start(void)
{
	int err;
	int res;
	const struct device *radio_clk_dev =
		DEVICE_DT_GET_OR_NULL(DT_CLOCKS_CTLR(DT_NODELABEL(radio)));
	struct onoff_client radio_cli;

	/** Keep radio domain powered all the time to reduce latency. */
	nrf_lrcconf_poweron_force_set(NRF_LRCCONF010, NRF_LRCCONF_POWER_DOMAIN_1, true);

	sys_notify_init_spinwait(&radio_cli.notify);

	err = nrf_clock_control_request(radio_clk_dev, NULL, &radio_cli);

	do {
		err = sys_notify_fetch_result(&radio_cli.notify, &res);
		if (!err && res) {
			LOG_ERR("Clock could not be started: %d", res);
			return res;
		}
	} while (err == -EAGAIN);

#if defined(NRF54L15_XXAA)
	/* MLTPAN-20 */
	nrf_clock_task_trigger(NRF_CLOCK, NRF_CLOCK_TASK_PLLSTART);
#endif /* defined(NRF54L15_XXAA) */

	LOG_DBG("HF clock started");

	return 0;
}

#else
BUILD_ASSERT(false, "No Clock Control driver");
#endif /* defined(CONFIG_CLOCK_CONTROL_NRF2) */

int esb_initialize(void)
{
	int err;
	/* These are arbitrary default addresses. In end user products
	 * different addresses should be used for each set of devices.
	 */
	uint8_t base_addr_0[4] = {0xE7, 0xE7, 0xE7, 0xE7};
	uint8_t base_addr_1[4] = {0xC2, 0xC2, 0xC2, 0xC2};
	uint8_t addr_prefix[8] = {0xE7, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8};

	struct esb_config config = ESB_DEFAULT_CONFIG;

	config.protocol = ESB_PROTOCOL_ESB_DPL;
	config.bitrate = ESB_BITRATE_2MBPS;
	config.mode = ESB_MODE_PRX;
	config.event_handler = event_handler;
	config.selective_auto_ack = true;
	config.use_fast_ramp_up = true;

	err = esb_init(&config);
	if (err) {
		return err;
	}

	err = esb_set_base_address_0(base_addr_0);
	if (err) {
		return err;
	}

	err = esb_set_base_address_1(base_addr_1);
	if (err) {
		return err;
	}

	err = esb_set_prefixes(addr_prefix, ARRAY_SIZE(addr_prefix));
	if (err) {
		return err;
	}

	return 0;
}

int main(void)
{
	int err;

	/* Initialise a semaphore that blocks access to the BOS1921 if it's already in use*/
	k_sem_init(&haptic_sem, 1, 1);

	LOG_INF("Enhanced ShockBurst prx sample");

	err = clocks_start();
	if (err) {
		return 0;
	}

	err = esb_initialize();
	if (err) {
		LOG_ERR("ESB initialization failed, err %d", err);
		return 0;
	}

	LOG_INF("Initialization complete");

	err = esb_write_payload(&tx_payload);
	if (err) {
		LOG_ERR("Write payload, err %d", err);
		return 0;
	}

	LOG_INF("Setting up for packet receiption");

	err = esb_start_rx();
	if (err) {
		LOG_ERR("RX setup failed, err %d", err);
		return 0;
	}

	////////// NVS SETUP //////////
	
	int rc = 0;
	struct flash_pages_info info;

	/* define the nvs file system by settings with:
	*	sector_size equal to the pagesize,
	*	3 sectors
	*	starting at NVS_PARTITION_OFFSET
	*/
	fs.flash_device = NVS_PARTITION_DEVICE;
	if (!device_is_ready(fs.flash_device)) {
		printk("Flash device %s is not ready\n", fs.flash_device->name);
		return 0;
	}
	fs.offset = NVS_PARTITION_OFFSET;
	rc = flash_get_page_info_by_offs(fs.flash_device, fs.offset, &info);
	if (rc) {
		printk("Unable to get page info, rc=%d\n", rc);
		return 0;
	}
	fs.sector_size = info.size;
	fs.sector_count = 3U;

	rc = nvs_mount(&fs);
	if (rc) {
		printk("Flash Init failed, rc=%d\n", rc);
		return 0;
	}

	rc = nvs_read(&fs, KEY_ID, &key, sizeof(key));

	if (rc > 0) { /* data was found, show it */
		printk("Id: %d, NVS: ", KEY_ID);
		for (int n = 0; n < 8; n++) {
			printk("%x ", key[n]);
		}
		printk("\n");

	} else   {/* data was not found, add it */
		printk("No data found, adding it at id %d\n", KEY_ID);
		key[0] = 0x0F;		/* Max amplitude as default - 0x0FFF*/
		key[1] = 0xFF;
		key[2] = 0x04;		/* No. cycles = 4 as default for 40ms pulse*/
		key[3] = 0x1A;		/* Frequency = 100Hz as default*/
		key[4] = 0x00;		/* Sleep Mode - OFF as default*/
		key[5] = 0x00;		/* Time On - 0 as default*/
		key[6] = 0x00;		/* Time Off - 0 as default*/
		(void)nvs_write(&fs, KEY_ID, &key, sizeof(key));
	}

	AMP_MSB = key[0];
	AMP_LSB = key[1];

	CYC = key[2];
	FREQ = key[3];

	SLEEP_CONFIG = key[4];
	SLEEP_ON = key[5];
	SLEEP_OFF = key[6];

	////////// BOS1921 SETUP //////////
	uint8_t dummy_data[3] = {0x00, 0x00, 0x00};

	/* Setup Slice that will be played on trigger, use values from NVS so 
		it isn't necessary to reset the settings every power cycle*/
	uint8_t setup_data[28] = {0x05, 0x16, 0x10, 0x00, 0x00, 0x01, 0x00, 
		0x00, 0x01 , 0x00, 0x01, 0x02, 0x00, 0x01, 0x00, 0x01, 0x01,
		0x00, AMP_MSB, AMP_LSB, CYC, FREQ, 0x04, 0x00, 0x00, 0x12, 0x00, 0x00};

	LOG_INF("Setting up Waveform Slice: ");
	for (int i = 0; i < sizeof(setup_data); i++) {
		LOG_INF("0x%02X", setup_data[i]);
	}

	if (!device_is_ready(dev_i2c.bus)){
		printk("i2c dev not ready\n");
		return;
	}

	/* Write dummy data to BOS1921 to wake it up*/
	err = i2c_write_dt(&dev_i2c, dummy_data, sizeof(dummy_data));
	if (err<0){
		printk("Initial Wakeup Write Failed: %d\n", err);
		return;
	}
	k_msleep(3);
	
	err = i2c_write_dt(&dev_i2c, setup_data, sizeof(setup_data));
	if (err<0){
		printk("Setup Write Failed: %d\n", err);
		return;
	}

	/* return to idle thread and wait for packets */
	return 0;
}


